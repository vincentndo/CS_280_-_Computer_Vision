function [mag,theta] = derivative_gaussian_filter(I, sigma)
% compute magnitude and theta of image I
