function [mag,theta] = difference_filter(I)
% compute magnitude and theta of image I
