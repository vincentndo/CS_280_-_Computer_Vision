import numpy as np

def difference_filter(I):
	print 0

def derivative_gaussian_filter(I,sigma):
	print 0

def oriented_filter(I):
	print 0