function [mag,theta] = oriented_filter(I)
% compute magnitude and theta of image I
